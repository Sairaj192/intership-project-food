import React from 'react';
import { ChefHat, Clock, Star, UtensilsCrossed } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div 
        className="h-[600px] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative h-full flex items-center justify-center">
          <div className="text-center text-white px-4">
            <h1 className="text-5xl font-bold mb-6">Fresh & Delicious</h1>
            <p className="text-xl mb-8">Experience culinary excellence at its finest</p>
            <button className="bg-orange-500 text-white px-8 py-3 rounded-full hover:bg-orange-600 transition">
              View Menu
            </button>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <ChefHat className="w-12 h-12 mx-auto mb-4 text-orange-500" />
            <h3 className="text-xl font-semibold mb-2">Expert Chefs</h3>
            <p className="text-gray-600">Crafted by culinary masters</p>
          </div>
          <div className="text-center">
            <UtensilsCrossed className="w-12 h-12 mx-auto mb-4 text-orange-500" />
            <h3 className="text-xl font-semibold mb-2">Quality Food</h3>
            <p className="text-gray-600">Fresh ingredients daily</p>
          </div>
          <div className="text-center">
            <Clock className="w-12 h-12 mx-auto mb-4 text-orange-500" />
            <h3 className="text-xl font-semibold mb-2">Fast Service</h3>
            <p className="text-gray-600">Quick and efficient delivery</p>
          </div>
        </div>
      </div>

      {/* Featured Dishes */}
      <div className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Dishes</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Grilled Salmon",
                price: "$24.99",
                image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&q=80",
                rating: 4.8
              },
              {
                name: "Pasta Carbonara",
                price: "$18.99",
                image: "https://images.unsplash.com/photo-1612874742237-6526221588e3?auto=format&fit=crop&q=80",
                rating: 4.7
              },
              {
                name: "Beef Steak",
                price: "$29.99",
                image: "https://images.unsplash.com/photo-1546964124-0cce460f38ef?auto=format&fit=crop&q=80",
                rating: 4.9
              }
            ].map((dish, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition">
                <img 
                  src={dish.image} 
                  alt={dish.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-2">{dish.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-orange-500 font-bold">{dish.price}</span>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="ml-1 text-gray-600">{dish.rating}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p>&copy; 2024 Fresh & Delicious. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;